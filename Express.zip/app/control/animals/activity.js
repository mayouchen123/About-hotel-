"use strict";
var Activity = require('../../model/animals/activity');  //model层

exports.getActivity = function (args,fn) {                  //control层
    var activity = new Activity();
    activity.getActivity(args,fn);
   /* activity.getweather(args,fn);*/
  }



