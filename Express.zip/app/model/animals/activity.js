var proxy = require("../../utils/proxy"),
	http = require("http")
	/*config_development = require("../../utils/config_development")*/

function Activity(){

}
Activity.prototype = {
	//获取天气的接口1调用
	getActivity: function(args,fn){
		proxy.invoke({
			data:{_header: {apikey: "975ba874887152c785996390732726e5"}, cityname: "上海"},
			host:"apis.baidu.com",
			path:"/apistore/weatherservice/citylist?cityname=%E6%9C%9D%E9%98%B3",
	       	method:"GET"
	    }, function(err, result){
			console.log(result);
			fn(err, result);
		});
	}

	/*//获取天气的接口2调用
	getweather: function(args,fn){
		proxy.invoke({
			data:{key:"975ba874887152c785996390732726e5", cityname: "北京",dtype:"JSON"},
			host:"op.juhe.cn",
			path:"/onebox/weather/query",
			method:"GET"
		}, function(err, result){
			console.log(result);
			fn(err, result);
		});
	}*/
}

module.exports = Activity;