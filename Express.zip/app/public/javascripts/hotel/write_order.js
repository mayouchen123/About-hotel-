"use strict";
$(function () {
    /*房间样式改变*/
    var countPlus = Number(document.getElementById('count-number').innerHTML);
    if(countPlus===0){
        $("#minNum").css({
            background:"#eeeeee"
        });
    }else{
        $("#minNum").css({
            background:"#ffffff"
        });
    }

    /*房间数变少*/
    function roomMin(){
        "use strict";
        document.getElementsByClassName("room-count-do")[0].getElementsByTagName("div").item(0).addEventListener("click", function(){
            if(countPlus>=1){
                document.getElementById('count-number').innerHTML = countPlus - 1;
            }
        });
    }
    /*房间数变多*/
    function roomPlus(){
        document.getElementsByClassName("room-count-do")[0].getElementsByTagName("div").item(2).addEventListener("click", function(){
            var countPlus = Number(document.getElementById('count-number').innerHTML);
            document.getElementById('count-number').innerHTML = countPlus + 1;
        });
    }


   /* 校验手机号码和用户名*/
    function verify_inputMessage(){

        $("#submit").click(function(){
            var name = $(".inut-name").val();
            var phone = $(".inut-phone").val();
            var reg=/^[\u4e00-\u9fa5]{0,}$/;

            if(!(reg.exec(name))){
               /* alert("用户名错误！");*/
                $(".input-name").after("<div class='error-name'>用户名错误！</div>").after("<div class='dialog'></div>");

            }else{
                if( !(/^1[34578]\d{9}$/.test(phone))){
                 /*   alert("手机号错误！");*/
                    $(".input-phonenum").after("<div class='error-phone'>手机号错误！</div>").after("<div class='dialog'></div>");
                }else{
                    //跳转到成功的页面
                    location.href = "/hotel/checkTime"; //这里跳转的是路由的路径
                }
            }

        });


        // 你要绑定的事件在这里
        $(document).on('click', '.dialog', function() {

           /*清除弹框和错误信息*/
            $(".dialog").css({
                display: "none"
            });
            $(".error-name").css({
                display: "none"
            });
            $(".error-phone").css({
                display: "none"
            });

        });

        //跳转回房间详情
        $(".pre-time").click(function(){
            location.href = "/hotel/houseDetail"; //这里跳转的是路由的路径
        });


        /* $(".dialog").click(function(){
            alert(1111);
            $(".input-name").removeClass("error-name").removeClass("dialog");
            $(".input-phonenum").removeClass("error-phone").removeClass("dialog")
        });*/
    }
    roomMin();
    roomPlus();
    verify_inputMessage();


});