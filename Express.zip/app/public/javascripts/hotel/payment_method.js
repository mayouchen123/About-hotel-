/**
 * Created by lenovo on 2016/10/25.
 */

window.onload = function(){
    $(".btn1").click(function(){
        $(".pay1").show();
        $(".pay2").hide();
        $(".pay3").hide();
        $(".pay4").hide();
        $(".pay5").hide();
    });
    $(".btn2").click(function(){
        $(".pay2").show();
        $(".pay1").hide();
        $(".pay3").hide();
        $(".pay4").hide();
        $(".pay5").hide();
    });
    $(".btn3").click(function(){
        $(".pay3").show();
        $(".pay2").hide();
        $(".pay1").hide();
        $(".pay4").hide();
        $(".pay5").hide();
    });
    $(".btn4").click(function(){
        $(".pay4").show();
        $(".pay2").hide();
        $(".pay3").hide();
        $(".pay1").hide();
        $(".pay5").hide();
    });

    $(".btn5").click(function(){
        $(".pay5").show();
        $(".pay2").hide();
        $(".pay3").hide();
        $(".pay4").hide();
        $(".pay1").hide();
    });

    $(".footer-head").click(function(){
        location.href = "/hotel/paymentStatus"; //������ת����·�ɵ�·��
    });

}


