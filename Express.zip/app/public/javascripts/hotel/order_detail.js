/**
 * Created by lenovo on 2016/10/18.
 */
$(function () {
    var intDiff = parseInt(60);//倒计时总秒数量
    function timer(intDiff) {
        window.setInterval(function () {
            var day = 0,
                hour = 0,
                minute = 0,
                second = 0;//时间默认值
            if (intDiff > 0) {
                day = Math.floor(intDiff / (60 * 60 * 24));
                hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
            }
            if (minute <= 9) minute = '0' + minute;
            if (second <= 9) second = '0' + second;
            $('#day_show').html(day + "天");
            $('#hour_show').html('<s id="h"></s>' + hour + '时');
            $('#minute_show').html('<s></s>' + minute + '分');
            $('#second_show').html('<s></s>' + second + '秒');
            intDiff--;
        }, 1000);

        setInterval(function(){
            if($('#minute_show').text() =='00分' &&  $('#second_show').text() =='00秒'){
                $('.pay-immediately-count').remove();
                $('.cancle-order').remove();
                $('.del-order').show();
                clearInterval();
            }
        },1000)

        $("#dingdan").click(function () {
            location.href = "/hotel/order"; //这里跳转的是路由的路径
        });
        $("#mengdian").click(function () {
            location.href = "/hotel"; //这里跳转的是路由的路径
        });
        $(".set-detail").click(function () {
            location.href = "/hotel/detail"; //这里跳转的是路由的路径
        });
        $(".set-detail-address").click(function () {
            location.href = "http://ditu.amap.com/"; //这里跳转的是路由的路径
        });
        $(".pay-immediately-count").click(function () {
            location.href = "/hotel/paymentMethod"; //这里跳转的是路由的路径
        });


       /* 点击删除按钮*/
        $('.del-order').click(function(){
            $(".arrow_mask").show();
            $(".cancel-order-dialog").show()
        })
       /* 弹框的设置---取消键*/
        $(".cancle-order-btn").click(function(){
            $(".cancel-order-dialog").hide();
            $(".arrow_mask").hide();
        });
        /* 弹框的设置---确定键*/
        $(".certain-order").click(function(){
            $(".section-first").remove();
            $(".cancel-order-dialog").remove();
            $(".arrow_mask").remove();
            $(".footer").css({"position":"fixed"});
        });
        /* 弹框的设置---取消键*/
        $(".cancle-order").click(function(){
            $(".section-first").remove();
            $(".footer").css({"position":"fixed"});
        });

    }

    $(function () {
        timer(intDiff);
    });

});