
window.onload = function() {

    $("#datePicker").focus(function(){
        document.activeElement.blur();
    });
    $("#datePicker2").focus(function(){
        document.activeElement.blur();
    });

    //跳转回房间详情
    $(".submit").click(function () {

        var date1 = $("#datePicker").val();
        var date2 = $("#datePicker2").val();
        var reg = /^(\d{4})-(0\d{1}|1[0-2])-(0\d{1}|[12]\d{1}|3[01])$/;//正则表达式
        if(!(reg.exec(date1))){
            $("#datePicker").after("<span class='error-date1'>请输入正确的入住日期</span>").after("<div class='dialog'></div>");
        }else if(!(reg.exec(date2))){
            $("#datePicker2").after("<span class='error-date1'>请输入正确的离开日期</span>").after("<div class='dialog'></div>");
        }else{
            location.href = "/hotel/orderDetail"; //这里跳转的是路由的路径
        }


        $(".dialog").click(function(){
            $(".dialog").css({
                display: "none"
            });
            $(".error-date1").css({
                display: "none"
            });
            $(".error-date2").css({
                display: "none"
            });
        });
    });

   /* function justify_date() {

        var date1 = $("#datePicker").val();
        var date2 = $("#datePicker2").val();
        var reg = /^(\d{4})-(0\d{1}|1[0-2])-(0\d{1}|[12]\d{1}|3[01])$/;//正则表达式

        location.href = "/hotel/orderDetail"; //这里跳转的是路由的路径
        */
        /*if(reg.exec(date1) ){
            alert(111);
            if(reg.exec(date2)){
                alert(111);
                location.href = "/hotel/orderDetail"; //这里跳转的是路由的路径
            }
        }*//*else{
            if(!(reg.exec(date1))){
                $("#datePicker").after("<span class='error-date1'>请输入正确的入住日期</span>").after("<div class='dialog'></div>");
            }else{
                $("#datePicker").after("<span class='error-date1'>请输入正确的离开日期</span>").after("<div class='dialog'></div>");
            }
        }*/

       /* $(document).live('click', '.dialog', function() {
            alert(111111);
            /!*清除弹框和错误信息*!/
            $(".dialog").css({
                display: "none"
            });
            $("#datePicker").css({
                display: "none"
            });
            $("#datePicker2").css({
                display: "none"
            });

        });*/

/*
    }*/

}
