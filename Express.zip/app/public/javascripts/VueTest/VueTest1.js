/**
 * Created by lenovo on 2017/2/21.
 */
    var aa = new Vue({
        el: '#helloVue',
        data: {
            number: "hello everyOne",
            animatedNumber: "this is my name"
        }
    })


/*// 定义模块  myModule.js
define(function(require, exports, module) {
    var $ = require('jquery.js')
    $('div').addClass('active');
});


// 加载模块
seajs.use(['myModule.js'], function(my){

});*/



