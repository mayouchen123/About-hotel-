var config = {
	port:5000,
	api:{
		"host":"mapi.dev.vd.cn",
		"port":80
	},
	//海燕 环信接口地址
	im:{
		"host":"121.43.197.98",
		"port":7074,
		"port2": 8899,
		"appKey": "dwm716#weiim"
	},
	//海燕
	coupon: {
		"host": "120.55.126.2",
		"port": "8888",
		"api": {
			"addCouponWithPhone": "/main-api/publishCardByCode"
		},
		"cusNo": "2147483640" //商户号
	},
	coupon2: {
		//"host": "10.51.28.109",//内网
		"host": "120.26.129.78",//外网
		"host2": "120.26.129.78",//外网
		"port": "8080",
		"port2": "8080",
		"api": {
			"exchange": "/mengdian-coupon-web/coupon/h5/exchange",
			"coupon":"/mengdian-coupon-web/coupon/h5/",
			"fissionCoupons": "/mengdian-coupon-web/coupon/h5/"
		}
	},
	indiana:{
		host:"114.55.38.178",
		port:"8081"
	},
	indianaRaider:{
		host:"112.124.28.82",
		port:"3005"
	},
	//促销专题接口
	promotion:{
		//"host":"10.252.218.121",
		"host":"112.124.28.82",
		"port":6005
	},
	wx:{
		
	},
	qqLbs:{
		"host":"apis.map.qq.com",
		"key": "AIEBZ-OPRHV-7MHPE-UC4QN-CC2BO-BIBNQ"
	},
	weichat:{
		aid: "667",
	  	AppID: "wx726413b361dff8af", //weimob013
      	AppSecret: "a08c60223e9cd416e3dc49da9e14cd89"
	},
	//旺铺接口
	wp:{
		wechatUc:{
			host:"112.124.16.233",
			port:11111
		},
		wechatToken:{
			host:"121.40.61.227",
			port:"8080",
			path:'/wxpublicapi/service/wxpublicapi?serviceName=wxTokenService&methodName=getAccessToken&paramterInput={"account_id":667,"need_refresh":false}'
		}
	},
	defaultShop: {
		vid: "21276"
	},
	db:{
		COOKIE_SECRET: 'cloudMall',
		DB: 'cloudMall_dev',
		PORT:'11211',
		USERNAME: 'memcached',
		PASSWORD: '',
		HOST: '121.43.196.204',
		// HOST:'127.0.0.1'
	},
	//redis
	rdb:{
		COOKIE_SECRET: 'cloudMall',
		DB: 'cloudMall_dev',
		PORT: '6410',//'6380',
		USERNAME: 'redis',
		PASSWORD: 'redis-dev-001',
		HOST: '121.43.196.204'
	},
	//获取参团人数的redis
	rdb2:{
		COOKIE_SECRET: 'cloudMall',
		DB: 'cloudMall_dev',
		PORT: '6379',//'6380',
		USERNAME: 'redis',
		PASSWORD: 'Knm8Nye442YLCGP5',
		HOST: 'c6a2778448dc4fc9.m.cnhza.kvstore.aliyuncs.com'
	},
	//统计
	statistics:{
		host: "112.124.11.130",
		port: 80
	},
	share: {
		url: "http://yunjie.vd.cn"
	},
	lama:{
		host:"112.124.11.130",
		port:7070
	},
	monitor: {
		host: "112.124.8.195",
		port: 8087
	},
	soaProxy: {
		host: "112.124.8.195",
		port: 8087
	},
	walletQQ: {
		appId: '101270804',
        appKey: '9ba370474f3ca2676e2328e33958a86b',
        business: 1,
        cardId: 'cSchdWx9fJmLt1r-DiahQp1zcH-DyUyw',
        qcAdmin: '3550177076215664636764'
	},
	recommend: {
		//host: "10.47.54.90",
		host: "120.27.162.234",
		host2: "120.27.162.234",
		host3: "120.27.162.234",
		host4: "120.27.162.234",
		host5: "120.27.162.234",
		host6: "112.124.8.195",
		host7: "120.27.162.234",
		port: 10000,
		port2: 8879,
		port3: 6666,
		port4: 8100,
		port5: 8879,
		port6: 8087,
		port7: 10111
	},
	materialService: {
		host: "112.124.28.82",
		port: 3009
	},
	// 拼团二期分组
	pintuanSecond:{
		host:"112.124.28.82",
		host2:'120.26.129.78', //卡券
		host3:'120.26.129.78', //萌团长业务
		port:3005,
		port2:8080,
		port3:8080
	},
	// 石磊 uc
	mduc: {
		host: "wxapi.api-dev.vd.cn",
		port: 80
	},
	couponPrefix:'/mengdian-coupon-web',
	couponPrefix2:'/mengdian-mtz-web',
	domain: "http://yunjie.vd.cn",
	mdDomain: "http://xxxx.md.yunjie.vd.cn"
};

module.exports = config;