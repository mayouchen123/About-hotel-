var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');// 第三方中间件 通过使用第三方中间件从而为 Express 应用增加更多功能。
var bodyParser = require('body-parser');    // 第三方中间件


//0-定义要打印车错误信息的函数
function logErrors(err, req, res, next) {           //logErrors 将请求和错误信息写入标准错误输出、日志或类似服务：
  console.error(err.stack);
  next(err);
}
function clientErrorHandler(err, req, res, next) {  //clientErrorHandler 的定义如下（注意这里将错误直接传给了 next）：
  if (req.xhr) {
    res.status(500).send({ error: 'Something blew up!' });
  } else {
    next(err);
  }
}
function errorHandler(err, req, res, next) {       //errorHandler 能捕获所有错误，其定义如下：
  res.status(500);
  res.render('error', { error: err });
}
//1-设置引入的路由文件了
var users = require('./routes/users');
var animals = require('./routes/animals/dog');
var  hotel =  require('./routes/hotel/hotel');
var  test =  require('./routes/test/test');

//2-在 Express 中使用模板引擎
/*views, 放模板文件的目录，比如： app.set('views', './views')
 view engine, 模板引擎，比如： app.set('view engine', 'jade')*/
var app = express();
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');


//3-执行路由和中间键
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

//4-将静态资源文件所在的目录作为参数传递给 express.static 中间件就可以提供静态资源文件的访问了。
/*******public 和 files 都保存了共享的静态文件（路径可以一样，但是一定要保证访问的静态文件文件名不一样）*****/
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname,'files')));

// 5-配置服务器
var server = app.listen(3000, function () {
  var host = server.address().address;
  var port = server.address().port;
  console.log('Example app listening at http://%s:%s', host, port);
});

// 6-执行路由
app.use(users);
app.use(animals);
app.use(hotel);
app.use(test);


// 7-catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});



// 8-开发者处理
// error handlers
// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// 9-production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});

// 9-1执行配置的打印错误信息
app.use(logErrors);
app.use(clientErrorHandler);
app.use(errorHandler);

//10-配置日志文件了

var log4js = require('log4js');
log4js.configure({
  appenders: [
    { type: 'console' }, //控制台输出
    {
      type: 'file', //文件输出
      filename: 'logs/access.log',
      maxLogSize: 1024,
      backups:3,
      category: 'normal'
    }
  ]
});
var logger = log4js.getLogger('normal');
logger.setLevel('INFO');
app.use(log4js.connectLogger(logger, {level:log4js.levels.INFO}));
logger.error("message error..."); //error 信息中英文都可以使用

module.exports = app;
