/**
 * Created by lenovo on 2016/9/28.
 */
var express = require('express');
var activity_ctr = require('../../control/animals/activity');
var dog = express.Router();
var async = require('async');

/* GET users animals */
dog.get('/animals', function(req, res, next) {
    res.render('animals/dog',{
        title:"animals zoo",
        pageName:"animals"
    });
});

/* GET users dog */
dog.get('/dog', function(req, res, next) {
    async.parallel({
            getActivity:function(fn){
                activity_ctr.getActivity({},function(err,result){
                   fn(null,result)
                })
            }
        },function(err,result){
            if(err){
                res.end(err)
            }else{
                res.render('animals/dog',{
                    title:"animals zoo",
                    pageName:"animals"
                });
            }
        }
    )
});

/*
/!* GET users pig *!/
dog.get('/pig', function(req, res, next) {
    async.parallel({
            getActivity:function(fn){
                activity_ctr.getActivity({},function(err,result){
                    fn(null,result)
                })
            }
        },function(err,result){
            if(err){
                res.end(err)
            }else{
                res.render('animals/pig',{
                    title:"animals zoo",
                    pageName:"animals"
                });
            }
        }
    )
});
*/
module.exports = dog;
