/**
 * Created by lenovo on 2016/10/12.
 */

var express = require('express');
var test = express.Router();
var async = require('async');


/* GET ֧��״̬ */
test.get('/test/testNotify', function(req, res, next){
    res.render('testDemo/Web_Notifications_API',{
        title:"Web_Notifications_APIʵ��",
        pageName:"Web_Notifications_API"
    });
});

/* GET ֧��״̬ */
test.get('/test/testMoveAPI', function(req, res, next){
    res.render('testDemo/test_moveAPI',{
        title:"�ƶ��豸APIʵ��",
        pageName:"testMoveAPI"
    });
});

/* GET ֧��״̬ */
test.get('/test/testCanvas', function(req, res, next){
    res.render('testDemo/test_canvas',{
        title:"�ƶ��豸APIʵ��",
        pageName:"testcanvas"
    });
});

module.exports = test;
