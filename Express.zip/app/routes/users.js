var express = require('express');
var router = express.Router();

//1-使用普通的请求
/* GET users listing. */
router.get('/', function(req, res, next) {
  console.log("111");
  res.end('respond with a resource');
});

router.get('/index', function(req, res, next) {
  res.render('index',{
    title:"1块买一个人",
    pageName:"OneGroup"
  });
});

router.get('/vue/test1', function(req, res, next) {  //测试VUE的数据
   /* console.log("Vue  test!");
    res.end('respond with a resource');*/
    res.render('VueTest/VueTest1',{
        title:"VUE数据测试",
        pageName:"VUE data messagess"
    });
});

router.get('/index', function(req, res, next) {
    res.render('index',{
        title:"1块买一个人",
        pageName:"OneGroup"
    });
});

//2-使用多个回调函数处理路由（记得指定 next 对象）：
router.get('/example/b', function (req, res, next) {
  console.log('response will be sent by the next function ...');
  next();
}, function (req, res) {
  res.send('Hello from B!');
});


//3-使用回调函数数组处理路由
var cb0 = function (req, res, next) {
  console.log('CB0');
  next();
}

var cb1 = function (req, res, next) {
  console.log('CB1');
  next();
}

var cb2 = function (req, res) {
  res.send('Hello from C!');
}

router.get('/example/c', [cb0, cb1, cb2]);
//4-混合使用函数和函数数组处理路由：
var cb3 = function (req, res, next) {
  console.log('CB0');
  next();
}

var cb4 = function (req, res, next) {
  console.log('CB1');
  next();
}

router.get('/example/d', [cb3, cb4], function (req, res, next) {
  console.log('response will be sent by the next function ...');
  next();
}, function (req, res) {
  res.send('Hello from D!');
});

//5-使用回调函数数组处理路由
/* 需要在中间件栈中跳过剩余中间件，调用 next('route') 方法将控制权交给下一个路由。
 注意： next('route') 只对使用 app.VERB() 或 router.VERB() 加载的中间件有效。*/

/*router.get('/user/:id', function (req, res, next) {
  // 如果 user id 为 0, 跳到下一个路由
  if (req.params.id == 0) next('route');
  // 否则将控制权交给栈中下一个中间件
  else next(); //
}, function (req, res, next) {
  // 渲染常规页面
  res.render('regular');
});*/

//6-错误处理中间件
/*错误处理中间件和其他中间件定义类似，只是要使用 4 个参数，而不是 3 个，其签名如下： (err, req, res, next)。*/
/*app.use(function(err, req, res, next) {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});*/

module.exports = router;